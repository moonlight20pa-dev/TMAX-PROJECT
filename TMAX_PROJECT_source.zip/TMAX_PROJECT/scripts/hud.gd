extends CanvasLayer

var speed_label: Label
var message_label: Label
var touch_state := {"accelerate": false, "brake": false, "steer_left": false, "steer_right": false}

func _ready() -> void:
    _create_hud()

func _create_hud() -> void:
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    speed_label = Label.new()
    speed_label.position = Vector2(28, 24)
    speed_label.add_theme_font_size_override("font_size", 28)
    speed_label.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(speed_label)
    message_label = Label.new()
    message_label.text = "TMAX PROJECT  |  عالم مفتوح"
    message_label.position = Vector2(28, 65)
    message_label.add_theme_font_size_override("font_size", 17)
    message_label.add_theme_color_override("font_color", Color(0.9, 0.9, 0.85))
    root.add_child(message_label)
    _add_hold_button(root, "◀", Vector2(35, -115), "steer_left", true)
    _add_hold_button(root, "▶", Vector2(145, -115), "steer_right", true)
    _add_hold_button(root, "فرامل", Vector2(-245, -120), "brake", false)
    _add_hold_button(root, "بنزين", Vector2(-125, -120), "accelerate", false)

func _add_hold_button(parent: Control, caption: String, offset: Vector2, action: String, left_side: bool) -> void:
    var button = Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(100, 78)
    button.add_theme_font_size_override("font_size", 21)
    button.modulate = Color(1, 1, 1, 0.82)
    if left_side:
        button.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
        button.position = Vector2(offset.x, offset.y)
    else:
        button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
        button.position = Vector2(offset.x, offset.y)
    parent.add_child(button)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))

func _process(_delta: float) -> void:
    var bike = get_parent().get_node_or_null("PlayerBike")
    if bike != null:
        speed_label.text = "%03d KM/H" % int(bike.speed * 3.6)
