extends Node3D

const BikeScript = preload("res://scripts/bike.gd")
const HudScript = preload("res://scripts/hud.gd")

func _ready() -> void:
    _build_environment()
    _build_city()
    var bike = CharacterBody3D.new()
    bike.name = "PlayerBike"
    bike.set_script(BikeScript)
    add_child(bike)
    bike.position = Vector3(0, 0.25, 8)
    var hud = CanvasLayer.new()
    hud.set_script(HudScript)
    add_child(hud)

func _mat(color: Color, roughness: float = 0.9) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, material: Material) -> MeshInstance3D:
    var mesh = BoxMesh.new()
    mesh.size = size
    var obj = MeshInstance3D.new()
    obj.mesh = mesh
    obj.position = pos
    obj.material_override = material
    parent.add_child(obj)
    return obj

func _build_environment() -> void:
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_SKY
    e.sky = Sky.new()
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.75, 0.78, 0.82)
    e.ambient_light_energy = 0.8
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -30, 0)
    sun.light_energy = 1.15
    add_child(sun)

func _build_city() -> void:
    var asphalt = _mat(Color(0.16, 0.17, 0.18))
    var sidewalk = _mat(Color(0.68, 0.64, 0.55))
    var stone = _mat(Color(0.72, 0.67, 0.57))
    var white = _mat(Color(0.92, 0.9, 0.82))
    var dark = _mat(Color(0.28, 0.29, 0.3))
    # Wide central street and sidewalks
    _box(self, Vector3(18, 0.15, 180), Vector3(0, -0.12, -70), asphalt)
    _box(self, Vector3(3, 0.22, 180), Vector3(-10.5, -0.08, -70), sidewalk)
    _box(self, Vector3(3, 0.22, 180), Vector3(10.5, -0.08, -70), sidewalk)
    # Lane markings
    for z in range(-155, 20, 12):
        _box(self, Vector3(0.18, 0.025, 5), Vector3(0, -0.025, z), white)
    # Repeating low-rise limestone buildings, balconies and windows
    for side in [-1, 1]:
        for i in range(12):
            var z = -145.0 + i * 14.0
            var x = side * 15.5
            var h = 7.0 + float(i % 3) * 1.2
            _box(self, Vector3(8, h, 10), Vector3(x, h / 2.0, z), stone)
            for floor in range(2):
                for w in range(2):
                    var wx = x - 1.7 + w * 3.4
                    var wy = 2.0 + floor * 2.7
                    _box(self, Vector3(1.1, 1.25, 0.12), Vector3(wx, wy, z - 5.06), dark)
                    _box(self, Vector3(1.1, 0.1, 0.55), Vector3(wx, wy - 0.7, z - 5.2), dark)
            # Rooftop water tank
            _box(self, Vector3(1.5, 1.3, 1.5), Vector3(x, h + 0.65, z), dark)
    # Side streets crossing the main road
    for z in [-120, -64, -8]:
        _box(self, Vector3(54, 0.13, 8), Vector3(0, -0.13, z), asphalt)
    # Distant hills
    var hill = _mat(Color(0.43, 0.48, 0.38))
    for i in range(7):
        var mound = MeshInstance3D.new()
        var sphere = SphereMesh.new()
        sphere.radius = 1
        sphere.height = 2
        mound.mesh = sphere
        mound.scale = Vector3(15, 5 + (i % 3) * 2, 18)
        mound.position = Vector3(-65 + i * 22, 2, -115 - (i % 2) * 22)
        mound.material_override = hill
        add_child(mound)
