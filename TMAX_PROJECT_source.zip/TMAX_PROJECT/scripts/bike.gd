extends CharacterBody3D

var speed := 0.0
var steering := 0.0
var max_speed := 34.0
var acceleration := 15.0
var braking := 27.0
var camera: Camera3D
var cockpit: MeshInstance3D
var handlebar: MeshInstance3D

func _ready() -> void:
    _make_bike_view()
    camera.current = true

func _make_bike_view() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 1.18, -0.42)
    camera.rotation_degrees = Vector3(-2, 0, 0)
    camera.fov = 78
    add_child(camera)
    # Simplified visible cockpit fairing and handlebar in first-person view
    cockpit = MeshInstance3D.new()
    var fairing = BoxMesh.new()
    fairing.size = Vector3(0.72, 0.18, 0.42)
    cockpit.mesh = fairing
    cockpit.position = Vector3(0, 0.78, -0.95)
    cockpit.material_override = _material(Color(0.045, 0.06, 0.075))
    camera.add_child(cockpit)
    handlebar = MeshInstance3D.new()
    var bar = BoxMesh.new()
    bar.size = Vector3(1.05, 0.055, 0.07)
    handlebar.mesh = bar
    handlebar.position = Vector3(0, 0.62, -0.72)
    handlebar.material_override = _material(Color(0.08, 0.08, 0.08))
    camera.add_child(handlebar)
    var dash = MeshInstance3D.new()
    var screen = BoxMesh.new()
    screen.size = Vector3(0.32, 0.12, 0.025)
    dash.mesh = screen
    dash.position = Vector3(0, 0.9, -0.72)
    dash.material_override = _material(Color(0.02, 0.16, 0.19))
    camera.add_child(dash)

func _material(c: Color) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = c
    roughness_setup(m)
    return m

func roughness_setup(m: StandardMaterial3D) -> void:
    m.roughness = 0.55

func _physics_process(delta: float) -> void:
    var accel_input = Input.get_action_strength("accelerate")
    var brake_input = Input.get_action_strength("brake")
    var left_input = Input.get_action_strength("steer_left")
    var right_input = Input.get_action_strength("steer_right")
    # Touch controls update these actions through HUD; keyboard works in editor too.
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        accel_input = 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        brake_input = 1.0
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        left_input = 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        right_input = 1.0
    speed += accel_input * acceleration * delta
    speed -= brake_input * braking * delta
    speed = clamp(speed, 0.0, max_speed)
    if accel_input < 0.05 and brake_input < 0.05:
        speed = move_toward(speed, 0.0, 2.0 * delta)
    steering = move_toward(steering, right_input - left_input, 3.2 * delta)
    rotation.y -= steering * (0.85 + speed / max_speed) * delta
    velocity = -global_transform.basis.z * speed
    velocity.y = -0.5
    move_and_slide()
    camera.rotation.z = lerp(camera.rotation.z, -steering * 0.08, delta * 4.0)
    camera.rotation.x = deg_to_rad(-2.0) - speed / max_speed * 0.025
